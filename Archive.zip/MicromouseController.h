//
// Created by Jakub Kurek on 20/03/2025.
//

#ifndef MICROMOUSECONTROLLER_H
#define MICROMOUSECONTROLLER_H
#include <qobject.h>

#include "MazeGenerator.h"


struct MicrmouseStep {
    QPoint pos;
    int orientation;
};


class MicromouseController {
public:
    explicit MicromouseController() {}
    virtual void setup(const Maze &m, const QPoint &start, const QPoint &goal) = 0;
    virtual void start() = 0;
    virtual void stop() = 0;
    virtual void update() = 0; // Called periodically
    virtual QPoint currentPosition() const = 0;
    virtual int currentOrientation() const = 0;
    virtual std::vector<MicrmouseStep> path() const = 0;
    bool isFinished = false;
};


#endif //MICROMOUSECONTROLLER_H
