//
// Created by Jakub Kurek on 20/03/2025.
//

#ifndef MAINWINDOW_H
#define MAINWINDOW_H




#include <QWidget>
#include "MazeVisualizer.h"
#include "MicromouseController.h"
#include <QPushButton>
#include <QComboBox>
#include <QCheckBox>

class MainWindow : public QWidget {
    Q_OBJECT
public:
    explicit MainWindow(QWidget *parent = nullptr);
    void startMazeGeneration();
    void skipMazeGenerationVisualistion();
    void startMicromouseSimulation();
private:
    MazeVisualizer *visualizer;
    QComboBox *mazeAlgoCombo;   // Maze generation algorithm
    QComboBox *mouseAlgoCombo;  // Micromouse algorithm
    QComboBox *solutionCombo;   // For solution endpoint
    QCheckBox *visualizeCheck;
    QPushButton *startMazeButton;
    QPushButton *skipMazeGenerationVisualiztionButton;
    QPushButton *startMouseButton;

    SolutionPoint determineSolutionPoint();
    MazeGenerator* determineMazeGenerator(int rows, int cols);
    MicromouseController* determineMicromouseController();
};

#endif //MAINWINDOW_H
