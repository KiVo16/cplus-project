
//
// Created by Jakub Kurek on 20/03/2025.
//

#ifndef MAZEGENERATOR_H
#define MAZEGENERATOR_H



#include <vector>
#include <QPoint>


// Directions: 0 = North, 1 = East, 2 = South, 3 = West.
enum Direction { UP = 0, RIGHT = 1, DOWN = 2, LEFT = 3 };

struct Cell {
    bool visited;
    bool walls[4]; // walls[0]=North, [1]=East, [2]=South, [3]=West.
    Cell() : visited(false) {
        walls[0] = walls[1] = walls[2] = walls[3] = true;
    }
};

typedef std::vector<std::vector<Cell>> Maze;

class MazeGenerator {
public:
    MazeGenerator(int rows, int cols)
        : rows(rows), cols(cols), finished(false) {
        maze.resize(rows, std::vector<Cell>(cols));
    }
    virtual ~MazeGenerator() {}
    // Perform one generation step.
    virtual bool step() = 0;
    bool isFinished() const { return finished; }
    // Return the maze (2D grid of Cells).
    const std::vector<std::vector<Cell>>& getMaze() const { return maze; }
    // Non-const version for modification.
    std::vector<std::vector<Cell>>& getMazeRef() { return maze; }
    // Optionally, return the current cell (for visualization).
    virtual QPoint getCurrentCell() const { return QPoint(-1, -1); }
protected:
    int rows, cols;
    bool finished;
    std::vector<std::vector<Cell>> maze;

};



#endif //MAZEGENERATOR_H
